<!--nav class="col-md-2 d-none d-md-block bg-light sidebar">
    <div class="dashboardlogo">
        <div class="name"></div>
        <a class="sidebar-brand" href="index.html">
            <img alt="Company Logo" src="<?= base_url('assets/img/CLMS.png') ?>">
        </a>
    </div>
    <div class="sidebar-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link active" href="<?= base_url('lending/dashboard') ?>">
                    Dashboard 
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('lending/customer') ?>">
                    Customers
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    Users
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('lending/loan') ?>">
                    Loans
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    Reports
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">
                    FAQ
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="<?= base_url('lending/logout') ?>">
                    Log Out
                </a>
            </li>
        </ul>
    </div>
</nav-->

<div class="sidebar">
        <div class="media">            
            <img src="<?= base_url('assets/img/logo.jpg'); ?>" alt="User Avatar" class="img-size-50 mr-3 img-circle" style="width: 180px; height: 180px;">
        </div>
        <!--h3>Bayad Namo Utang!</h3-->
        
        <a href="<?= base_url('lending/dashboard') ?>" <?= (isset($pageTitle) && $pageTitle=='Home') ? 'class="active"' : ''?> >Home</a>
        <a href="<?= base_url('lending/customer') ?>" <?= (isset($pageTitle) && $pageTitle=='Customers') ? 'class="active"' : ''?>>Customers</a>
        <a href="<?= base_url('lending/loan') ?>" <?= (isset($pageTitle) && $pageTitle=='Loans') ? 'class="active"' : ''?>>Loans</a>
        <a href="<?= base_url('lending/payment') ?>" <?= (isset($pageTitle) && $pageTitle=='Payments') ? 'class="active"' : ''?>>Payments</a>
        <a href="<?= base_url('lending/group') ?>" <?= (isset($pageTitle) && $pageTitle=='Groups') ? 'class="active"' : ''?>>Groups</a>
        <div class="sidebar-category">
            <h5>Reports</h5>
            <a href="<?= base_url('lending/report/summary') ?>" <?= (isset($pageTitle) && $pageTitle=='SummaryDR') ? 'class="active"' : ''?>>Summary (Date Range)</a>
            <a href="<?= base_url('lending/report/pendingPayments') ?>" <?= (isset($pageTitle) && $pageTitle=='Pending Payments') ? 'class="active"' : ''?>>Pending Payments</a>
            <a href="<?= base_url('lending/report/accountOfficers') ?>" <?= (isset($pageTitle) && $pageTitle=='Account Officers') ? 'class="active"' : ''?>>Account Officers</a>
        </div>
        
        <!--a href="<?= base_url('lending/withdraw') ?>" <?= (isset($pageTitle) && $pageTitle=='Withdraw') ? 'class="active"' : ''?>>Withdraw</a-->
        <a href="<?= base_url('lending/logout') ?>">Logout</a>
        
</div>
